import {View, Text} from 'react-native'

const NotFound = () => {
    return (
        <View>
            <Text>Lamentamos. Rota não encontrada!</Text>
        </View>
    )
}

export default NotFound